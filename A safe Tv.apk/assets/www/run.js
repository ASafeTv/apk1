window.app = {
    dataTvActivateForm: null,
    dataTvLoadingSpinner: null,
    dataTvActivateAction: null,
    dataTvInputNumber: null,
    dataTvBindLoadingMessage: null,
    dataTvLoadingMessageContainer: null,
    showActivateForm: function() {
        this.dataTvBindLoadingMessage.innerText = "";
        this.dataTvLoadingSpinner.style.display = "none";
        this.dataTvActivateForm.style.display = "block";
        this.dataTvInputNumber.focus();
    },

    showLoading: function(message) {
        this.dataTvBindLoadingMessage.innerText = (message === undefined) ? "" : message;
        this.dataTvActivateForm.style.display = "none";
        this.dataTvLoadingSpinner.style.display = "block";
    },
    handleActivate: function() {
        window.app.showLoading();
        window.TvInterface.activate(app.dataTvInputNumber.value);
    },
    setActivationCode: function(code){
        this.dataTvInputNumber.value = code;
    },
    initInterface: function(){
        if(window.hasOwnProperty('TvInterface')) {
            return;
        }

        window.TvInterface = {
            activate: function(activation) {
                window.app.showLoading("For preview purposes only (it will keep loading)");
                console.log("Activating: " + activation)
            },
            retry: function() {
                console.log("Retrying ...")
            },
            showSoftKeyboard: function(x, y, h) {
                console.log("Show soft keyboard")
            }
        }
    },
    handleFocus: function(e) {

        if (e.isComposing || e.keyCode === 229) {
            return;
        }

        if(e.keyCode === 13 && window.app.dataTvInputNumber === document.activeElement) {
            var viewportOffset = window.app.dataTvInputNumber.getBoundingClientRect();
            var top = viewportOffset.top + (window.app.dataTvInputNumber.offsetHeight -10);
            var left = viewportOffset.left + (window.app.dataTvInputNumber.offsetWidth -10);
            var height = Math.max( document.body.scrollHeight, document.body.offsetHeight,
                       document.documentElement.clientHeight, document.documentElement.scrollHeight, document.documentElement.offsetHeight );
            window.TvInterface.showSoftKeyboard(left, top, height);
            return;
        }

        var directions = ['left', 'up', 'right', 'down'],
            key = e.keyCode;

        if(!(key && key > 36 && key < 41)) {
            return;
        }

        var keyDirection = directions[key-37];

        if(keyDirection === "up" || keyDirection === "down" || keyDirection === "left") {
            window.app.dataTvInputNumber.focus();
            e.preventDefault();
        }

        if(keyDirection === "right") {
            window.app.dataTvActivateAction.focus();
             e.preventDefault();
        }
    },
    run: function() {
        this.self = this;
        this.dataTvActivateForm = document.querySelector('[data-tv-activate-form]');
        this.dataTvLoadingSpinner = document.querySelector('[data-tv-loading-spinner]');
        this.dataTvActivateAction = document.querySelector('[data-tv-activate-action]');
        this.dataTvBindLoadingMessage = document.querySelector('[data-tv-bind-loading-message]');
        this.dataTvInputNumber = document.querySelector('[data-tv-input-number]');
        this.initInterface();
        this.dataTvActivateAction.addEventListener("click", function (e){
            window.app.handleActivate();
        });

        document.onkeydown = this.handleFocus;
    }
};



window.app.run();